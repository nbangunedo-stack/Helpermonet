Monet helper - Kotlin minimal project prepared for Codemagic.

Upload this repo to GitHub and run Codemagic workflow 'Android Debug APK (safe-gradle)'.
